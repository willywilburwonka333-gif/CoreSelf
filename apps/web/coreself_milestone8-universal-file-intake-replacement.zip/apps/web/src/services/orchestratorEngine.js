const INTENT_RULES = [
  { intent: 'build_code', label: 'Developer build', regex: /\b(code|coding|build|fix|debug|bug|zip|replacement|file|files|upload|uploads|attached|attachment|screenshot|photo|picture|deploy|vercel|firebase|github|commit|push|npm|react|vite|api|javascript|jsx|css|html|typescript|node|terminal|command)\b/i, tools: ['memory-recall', 'file-intake', 'planning-engine', 'developer-build-assistant', 'bug-triage', 'release-command-helper', 'replacement-file-workflow', 'github-vercel-firebase'], answer: 'implementation' },
  { intent: 'research_compare', label: 'Research and compare', regex: /\b(search|internet|web|latest|current|look up|compare|sources|cite|verify|research|best|cheap|tool|tools|api|provider)\b/i, tools: ['memory-recall', 'web-research', 'research-comparator', 'action-queue'], answer: 'research-decision' },
  { intent: 'create_asset', label: 'Creator workflow', regex: /\b(image|picture|photo|screenshot|video|film clip|song|music|book|chapter|cover|thumbnail|tiktok|post|marketing|prompt|voice|audio|lyrics|poster|logo|trailer|reel|caption|ad|ebook|lore bible|app store|google play)\b/i, tools: ['memory-recall', 'file-intake', 'creator-suite', 'planning-engine', 'action-queue'], answer: 'creator-production' },
  { intent: 'business_money', label: 'Business/income', regex: /\b(business|income|money|grant|iba|forecast|loan|pitch|sales|launch|monetise|monetize|product|pricing|customers|market)\b/i, tools: ['memory-recall', 'business-builder', 'planning-engine', 'web-research'], answer: 'business-plan' },
  { intent: 'personal_memory', label: 'Memory update', regex: /\b(remember|save this|memory|goal|plan|project|task|todo|remind|reminder|schedule|habit)\b/i, tools: ['memory-recall', 'memory-compression', 'action-queue', 'planning-engine'], answer: 'memory-action' },
];

function unique(items = []) {
  return [...new Set(items.filter(Boolean))];
}

function detectIntent(input = '', attachments = []) {
  const hasAttachments = Array.isArray(attachments) && attachments.length > 0;
  const matched = INTENT_RULES.filter((rule) => rule.regex.test(input));
  if (hasAttachments && !matched.some((rule) => rule.intent === 'build_code')) {
    matched.unshift(INTENT_RULES[0]);
  }
  if (!matched.length) {
    return {
      intent: 'general_assistant',
      label: 'General assistant',
      confidence: 0.58,
      answer: 'direct-answer',
      tools: ['memory-recall', 'planning-engine'],
      matched: [],
    };
  }

  const primary = matched[0];
  return {
    intent: primary.intent,
    label: primary.label,
    confidence: Math.min(0.96, 0.72 + matched.length * 0.07),
    answer: primary.answer,
    tools: unique(matched.flatMap((rule) => rule.tools)),
    matched: matched.map((rule) => rule.intent),
  };
}

function mapToolStatus(toolIds = [], tools = []) {
  return toolIds.map((id) => {
    const found = tools.find((tool) => tool.id === id || tool.aliases?.includes?.(id));
    if (!found) return { id, name: id, status: 'Planned', permission: 'Ask first', executable: false };
    return {
      id: found.id,
      name: found.name,
      status: found.status,
      permission: found.permission,
      executable: found.status === 'Ready' && found.permission === 'Allowed',
      risk: found.risk || 'Medium',
    };
  });
}

function buildAnswerContract(intent, input = '') {
  if (intent.intent === 'research_compare') {
    return [
      'State the practical answer first.',
      'Separate good fits, possible later fits, and poor fits for Core Self.',
      'Do not list tools without evaluating them against Dylan\'s actual stack.',
      'Flag hype, embedded-only projects, dead/unverified projects, or tools that do not help the React/Firebase/Vercel/OpenAI architecture.',
      'End with a short recommendation and next action.',
    ];
  }

  if (intent.intent === 'build_code') {
    return [
      'Identify the exact project layer.',
      'List only files that must change.',
      'Give exact terminal commands.',
      'Say what changed and what to test.',
      'Do not reset the workflow or ask for already provided setup.',
      'For new files, provide exact names and folders before the TXT content.',
      "Respect Dylan's individual TXT replacement workflow.",
    ];
  }

  if (intent.intent === 'create_asset') {
    return [
      'Identify the creator lane first: image, video, music, book, marketing, business document, or product/code.',
      'Use Dylan\'s existing projects, lore, brand direction, family context, app launch status and saved memory.',
      'Give the finished usable output when possible; otherwise give a tight production prompt with settings, structure and next steps.',
      'Separate what Core Self can produce now from what needs an external generator/API later.',
      'End with the next production action, not a vague suggestion.',
    ];
  }

  if (intent.intent === 'business_money') {
    return [
      'Tie advice to Dylan\'s actual apps, funding, family/time constraints and launch stage.',
      'Prefer low-cost, practical actions over generic business advice.',
      'Separate immediate cash moves from long-term asset moves.',
    ];
  }

  if (intent.intent === 'personal_memory') {
    return [
      'Decide whether the item should become memory, goal, task, plan, or project update.',
      'Ask for confirmation only when the exact wording or time matters.',
      'Prepare the action clearly without claiming external execution.',
    ];
  }

  return [
    'Answer directly.',
    'Use memory and current project context.',
    'End with one useful next step when appropriate.',
  ];
}

export function buildOrchestratorPlan({ input = '', mode = 'standard', tools = [], deepThink = false, attachments = [] } = {}) {
  const detected = detectIntent(input, attachments);
  const selectedTools = mapToolStatus(detected.tools, tools);
  const executableTools = selectedTools.filter((tool) => tool.executable);
  const blockedTools = selectedTools.filter((tool) => !tool.executable);

  const plan = {
    version: 'milestone-5-tool-runtime',
    intent: detected.intent,
    label: detected.label,
    confidence: detected.confidence,
    answerStyle: detected.answer,
    mode,
    deepThink: Boolean(deepThink),
    attachments: attachments.map((file) => ({ name: file.name, kind: file.kind, type: file.type, sizeLabel: file.sizeLabel })),
    selectedTools,
    executableToolCount: executableTools.length,
    blockedToolCount: blockedTools.length,
    blockedTools,
    answerContract: buildAnswerContract(detected, input),
    shouldUseMemory: true,
    shouldUseWeb: detected.intent === 'research_compare',
    shouldCreateAction: ['build_code', 'research_compare', 'business_money', 'personal_memory'].includes(detected.intent),
    shouldCompareToCoreStack: ['research_compare', 'build_code', 'business_money'].includes(detected.intent),
    completionRule: 'Finish with a recommendation, next action, and whether this should be saved as memory/task/project when relevant.',
  };

  return plan;
}

export function summarizeOrchestratorPlan(plan = {}) {
  if (!plan.intent) return 'Orchestrator not loaded.';
  const tools = (plan.selectedTools || []).map((tool) => `${tool.name || tool.id}: ${tool.status}`).join(' • ');
  return `${plan.label || plan.intent} • ${plan.answerStyle || 'direct-answer'} • ${tools || 'No tools selected'}`;
}
