import { useState } from 'react';
import { load, save } from '../services/localStore';
import { routeCoreRequest } from '../services/aiRouter';
import { logActivity } from '../services/activityLog';
import { suggestMemoryFromMessage } from '../services/memorySuggestions';
import { defaultGoals, defaultLifeGraphRelationships, defaultProjects } from '../data/defaults';
import PresenceBanner from '../components/PresenceBanner';

export default function Talk({ mode }) {
  const [messages, setMessages] = useState(load('messages', [
    { from: 'core', text: 'I am Dylan Core Genesis. Teach me, and I will grow into your Core.' },
  ]));
  const [input, setInput] = useState('');
  const [suggestion, setSuggestion] = useState(null);
  const [lastPrompt, setLastPrompt] = useState('');

  async function send() {
    const clean = input.trim();
    if (!clean) return;

    const memories = load('memories', []);
    const projects = load('projects', defaultProjects);
    const goals = load('goals', defaultGoals);
    const relationships = load('lifeGraphRelationships', defaultLifeGraphRelationships);
    const routed = await routeCoreRequest({ input: clean, mode, memories, projects, goals, relationships });
    const possibleMemory = suggestMemoryFromMessage(clean);

    const next = [
      ...messages,
      { from: 'dylan', text: clean },
      { from: 'core', text: routed.reply },
    ];

    setMessages(next);
    save('messages', next);
    setLastPrompt(routed.prompt);
    setSuggestion(possibleMemory);
    save('lastCorePrompt', routed.prompt);

    logActivity({
      engine: 'AI Router',
      action: 'Processed message',
      detail: `Mode ${mode}. Context used: ${routed.contextUsed.relevantMemories} relevant memories, ${routed.contextUsed.relationships} relationships.`,
    });

    setInput('');
  }

  function acceptSuggestion() {
    if (!suggestion) return;
    const current = load('memories', []);
    save('memories', [suggestion, ...current]);
    logActivity({ engine: 'Memory Engine', action: 'Accepted conversation memory', detail: suggestion.title });
    setSuggestion(null);
  }

  return (
    <section className="screen">
      <h2>Talk</h2>
      <PresenceBanner mode={mode} />

      <div className="chat">
        {messages.map((m, i) => <div key={i} className={'bubble ' + m.from}>{m.text}</div>)}
      </div>

      {suggestion && (
        <div className="presenceBanner">
          <span>Memory Suggestion</span>
          <p>{suggestion.title}</p>
          <button className="primary" onClick={acceptSuggestion}>Save Suggested Memory</button>
          <button className="danger" onClick={() => setSuggestion(null)}>Dismiss</button>
        </div>
      )}

      <div className="inputRow">
        <input value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && send()} placeholder="Speak to Dylan Core..." />
        <button onClick={send}>Send</button>
      </div>

      {lastPrompt && (
        <details className="debugPanel">
          <summary>Core Prompt Preview</summary>
          <pre>{lastPrompt}</pre>
        </details>
      )}
    </section>
  );
}
