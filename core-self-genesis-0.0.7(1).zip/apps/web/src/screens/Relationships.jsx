import { useState } from 'react';
import { defaultLifeGraphRelationships } from '../data/defaults';
import { load, save } from '../services/localStore';
import { logActivity } from '../services/activityLog';

export default function Relationships() {
  const [relationships, setRelationships] = useState(load('lifeGraphRelationships', defaultLifeGraphRelationships));
  const [form, setForm] = useState({ from: '', to: '', type: 'relates to', strength: 3, detail: '' });

  function persist(next) {
    setRelationships(next);
    save('lifeGraphRelationships', next);
  }

  function addRelationship() {
    if (!form.from.trim() || !form.to.trim()) return;
    const rel = { id: crypto.randomUUID(), ...form, strength: Number(form.strength) };
    persist([rel, ...relationships]);
    logActivity({ engine: 'Life Graph Engine', action: 'Added relationship', detail: `${rel.from} ${rel.type} ${rel.to}` });
    setForm({ from: '', to: '', type: 'relates to', strength: 3, detail: '' });
  }

  function update(id, key, value) {
    persist(relationships.map((r) => r.id === id ? { ...r, [key]: key === 'strength' ? Number(value) : value } : r));
  }

  function remove(id) {
    persist(relationships.filter((r) => r.id !== id));
    logActivity({ engine: 'Life Graph Engine', action: 'Removed relationship', detail: id, level: 'Warning' });
  }

  return (
    <section className="screen">
      <h2>Relationships</h2>
      <p className="muted">Relationships make the Life Graph useful. They show how Dylan’s life, projects, goals, and engines connect.</p>

      <div className="formGrid">
        <input value={form.from} onChange={(e) => setForm({ ...form, from: e.target.value })} placeholder="From" />
        <input value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })} placeholder="Relationship type" />
        <input value={form.to} onChange={(e) => setForm({ ...form, to: e.target.value })} placeholder="To" />
      </div>
      <input type="number" min="1" max="5" value={form.strength} onChange={(e) => setForm({ ...form, strength: e.target.value })} placeholder="Strength 1-5" />
      <textarea value={form.detail} onChange={(e) => setForm({ ...form, detail: e.target.value })} placeholder="Relationship detail..." />
      <button className="primary" onClick={addRelationship}>Add Relationship</button>

      <div className="list">
        {relationships.map((rel) => (
          <article key={rel.id}>
            <div className="formGrid">
              <input value={rel.from} onChange={(e) => update(rel.id, 'from', e.target.value)} />
              <input value={rel.type} onChange={(e) => update(rel.id, 'type', e.target.value)} />
              <input value={rel.to} onChange={(e) => update(rel.id, 'to', e.target.value)} />
            </div>
            <input type="number" min="1" max="5" value={rel.strength} onChange={(e) => update(rel.id, 'strength', e.target.value)} />
            <textarea value={rel.detail} onChange={(e) => update(rel.id, 'detail', e.target.value)} />
            <button className="danger" onClick={() => remove(rel.id)}>Remove Relationship</button>
          </article>
        ))}
      </div>
    </section>
  );
}
