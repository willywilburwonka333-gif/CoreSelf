import { useState } from 'react';
import { getFirebaseConfigDraft, saveFirebaseConfigDraft, firebaseReadiness, anonymousAuthPrep } from '../services/firebasePrep';
import { logActivity } from '../services/activityLog';

const fields = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId'];

export default function Firebase() {
  const [config, setConfig] = useState(getFirebaseConfigDraft());
  const [status, setStatus] = useState(firebaseReadiness(config));
  const [authMessage, setAuthMessage] = useState('');

  function update(key, value) {
    const next = { ...config, [key]: value };
    setConfig(next);
    saveFirebaseConfigDraft(next);
    setStatus(firebaseReadiness(next));
  }

  async function testAuthPrep() {
    const result = await anonymousAuthPrep();
    setAuthMessage(result.message);
    logActivity({ engine: 'Firebase Prep', action: 'Checked anonymous auth prep', detail: result.message });
  }

  return (
    <section className="screen">
      <h2>Firebase Prep</h2>
      <p className="muted">This does not connect yet. It prepares the config structure for the next phase.</p>

      <div className="briefing">
        <h3>{status.status}</h3>
        <p>{status.ready ? 'Config fields are filled. Next build can wire Firebase SDK.' : `Missing: ${status.missing.join(', ') || 'none'}`}</p>
      </div>

      <div className="list">
        <article>
          <h3>Firebase Config Draft</h3>
          {fields.map((field) => (
            <input key={field} value={config[field] || ''} onChange={(e) => update(field, e.target.value)} placeholder={field} />
          ))}
          <button className="primary" onClick={testAuthPrep}>Check Anonymous Auth Prep</button>
          {authMessage && <p>{authMessage}</p>}
        </article>
      </div>
    </section>
  );
}
