const items = [
  ['Dream Product', 9],
  ['Phone App', 38],
  ['Useful AI Foundation', 25],
  ['Learning AI Self', 12],
  ['Autonomous Helper', 2],
];

export default function ProgressTracker() {
  return (
    <div className="progressPanel">
      <h3>Build Progress</h3>
      {items.map(([name, value]) => (
        <div className="progressRow" key={name}>
          <div>
            <span>{name}</span>
            <strong>{value}%</strong>
          </div>
          <div className="bar"><i style={{ width: `${value}%` }} /></div>
        </div>
      ))}
    </div>
  );
}
