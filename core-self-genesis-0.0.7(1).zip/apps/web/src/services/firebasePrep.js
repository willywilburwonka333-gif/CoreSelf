import { load, save } from './localStore';
import { defaultFirebaseConfig } from '../data/defaults';

export function getFirebaseConfigDraft() {
  return load('firebaseConfigDraft', defaultFirebaseConfig);
}

export function saveFirebaseConfigDraft(config) {
  save('firebaseConfigDraft', config);
  return config;
}

export function firebaseReadiness(config = getFirebaseConfigDraft()) {
  const required = ['apiKey', 'authDomain', 'projectId', 'appId'];
  const missing = required.filter((key) => !String(config[key] || '').trim());

  return {
    ready: missing.length === 0,
    missing,
    status: missing.length === 0 ? 'Ready for Firebase wiring' : 'Config incomplete',
  };
}

export async function anonymousAuthPrep() {
  return {
    ok: false,
    prepared: true,
    message: 'Anonymous auth is prepared conceptually but Firebase SDK is not wired yet.',
  };
}
