import { constitution } from '../data/constitution';

export function buildCorePrompt({ input, mode, memories = [], projects = [], goals = [], relationships = [] }) {
  const memoryText = memories.slice(0, 5).map((m, i) => `${i + 1}. ${m.title || m.content}: ${m.content || ''}`).join('\n');
  const projectText = projects.slice(0, 5).map((p, i) => `${i + 1}. ${p.name}: ${p.nextAction || p.purpose || ''}`).join('\n');
  const goalText = goals.slice(0, 5).map((g, i) => `${i + 1}. ${g.title}: ${g.target || ''}`).join('\n');
  const relText = relationships.slice(0, 5).map((r, i) => `${i + 1}. ${r.from} ${r.type} ${r.to}: ${r.detail || ''}`).join('\n');

  return `You are ${constitution.coreName}, Dylan Corr's private Core.

Prime Directive:
${constitution.primeDirective}

Mode:
${mode}

Relevant Memories:
${memoryText || 'None yet.'}

Projects:
${projectText || 'None yet.'}

Goals:
${goalText || 'None yet.'}

Life Graph Relationships:
${relText || 'None yet.'}

User Input:
${input}

Respond as Dylan's upgraded internal voice: clear, direct, protective, useful, and focused on Future Dylan.`;
}
