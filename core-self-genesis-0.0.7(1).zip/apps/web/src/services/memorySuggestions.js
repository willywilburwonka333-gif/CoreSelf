export function suggestMemoryFromMessage(message) {
  const text = String(message || '').trim();
  const lower = text.toLowerCase();

  if (!text || text.length < 18) return null;

  const triggers = ['remember', 'save', 'from now on', 'always', 'never', 'i want', 'i prefer', 'my goal', 'important'];
  const shouldSuggest = triggers.some((trigger) => lower.includes(trigger));

  if (!shouldSuggest) return null;

  let type = 'Dylan Memory';
  if (lower.includes('goal')) type = 'Goal';
  if (lower.includes('prefer') || lower.includes('like this')) type = 'Preference';
  if (lower.includes('never') || lower.includes('risk')) type = 'Warning';
  if (lower.includes('project') || lower.includes('app')) type = 'Project';

  return {
    id: crypto.randomUUID(),
    type,
    level: lower.includes('always') || lower.includes('never') ? 'Long-term' : 'Active',
    importance: lower.includes('important') || lower.includes('always') || lower.includes('never') ? 'High' : 'Medium',
    title: text.slice(0, 58),
    content: text,
    lesson: '',
    futureAction: 'Use this to respond more like Dylan Core should.',
    truthStatus: 'Suggested from conversation',
    createdAt: new Date().toISOString(),
  };
}
