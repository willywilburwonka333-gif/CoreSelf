import { coreReply } from './coreReply';
import { retrieveRelevantMemories } from './memoryRetrieval';
import { buildCorePrompt } from './promptBuilder';

/**
 * Genesis AI Router placeholder.
 * 0.0.7 now builds the full Core prompt that future model APIs will receive.
 */
export async function routeCoreRequest({ input, mode, memories = [], projects = [], goals = [], relationships = [] }) {
  const relevantMemories = retrieveRelevantMemories(input, memories, 5);
  const prompt = buildCorePrompt({
    input,
    mode,
    memories: relevantMemories,
    projects,
    goals,
    relationships,
  });

  return {
    mode,
    provider: 'local-genesis-placeholder',
    confidence: 0.48,
    reply: coreReply(input, mode, relevantMemories),
    prompt,
    contextUsed: {
      memories: memories.length,
      relevantMemories: relevantMemories.length,
      projects: projects.length,
      goals: goals.length,
      relationships: relationships.length,
    },
    relevantMemories,
  };
}
