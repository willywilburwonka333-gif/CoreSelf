# Core Self

**Version:** Genesis 0.0.7  
**Founder:** Dylan Corr  
**First Core:** Dylan Core  

Core Self is a lifelong AI platform designed to help one human become the highest version of themselves.

## Start Web App

```bash
cd apps/web
npm install
npm run dev
```

Open forwarded port **5173** in Codespaces.

## Genesis 0.0.7 Adds

- Firebase config readiness form
- Anonymous auth preparation layer
- Stronger AI Router prompt builder
- Conversation-to-memory suggestions
- Life Graph relationship foundation
- Relationship editor screen
- AI context preview in Talk
- Safer cloud status handling
- Progress raised to dream product ~9%
