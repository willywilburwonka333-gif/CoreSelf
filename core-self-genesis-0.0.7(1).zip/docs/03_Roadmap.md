# Roadmap

## Genesis 0.0.7

- Firebase config readiness form
- Anonymous auth preparation
- Stronger AI Router prompt builder
- Conversation-to-memory suggestions
- Life Graph relationships

## Next: Genesis 0.0.8

- Real Firebase dependency wiring
- Optional local Firebase config save
- Better memory suggestion acceptance flow
- Relationship-aware briefing
- Basic Core prompt preview/export
