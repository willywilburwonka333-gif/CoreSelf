function json(res, status, payload) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(payload));
}

function dataUrlToBuffer(dataUrl = '') {
  const match = String(dataUrl).match(/^data:([^;]+)?;base64,(.*)$/s);
  if (!match) return Buffer.alloc(0);
  return Buffer.from(match[2], 'base64');
}

function formatBytes(bytes = 0) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(2)} MB`;
}

function parseZipEntries(buffer) {
  const entries = [];
  let offset = 0;
  while (offset < buffer.length - 30 && entries.length < 500) {
    const sig = buffer.readUInt32LE(offset);
    if (sig !== 0x04034b50) {
      offset += 1;
      continue;
    }
    const flags = buffer.readUInt16LE(offset + 6);
    const compressedSize = buffer.readUInt32LE(offset + 18);
    const uncompressedSize = buffer.readUInt32LE(offset + 22);
    const fileNameLength = buffer.readUInt16LE(offset + 26);
    const extraLength = buffer.readUInt16LE(offset + 28);
    const nameStart = offset + 30;
    const nameEnd = nameStart + fileNameLength;
    const name = buffer.slice(nameStart, nameEnd).toString('utf8');
    if (name) {
      entries.push({
        name,
        directory: name.endsWith('/'),
        compressedSize,
        uncompressedSize,
        sizeLabel: formatBytes(uncompressedSize),
        extension: name.includes('.') ? name.split('.').pop().toLowerCase() : '',
      });
    }
    if (flags & 0x08 || compressedSize === 0xffffffff) {
      offset = nameEnd + extraLength + Math.max(compressedSize, 0);
    } else {
      offset = nameEnd + extraLength + compressedSize;
    }
  }
  return entries;
}

function buildProjectSignals(entries = []) {
  const names = entries.map((entry) => entry.name);
  const hasPackage = names.some((name) => /(^|\/)package\.json$/i.test(name));
  const hasVite = names.some((name) => /(^|\/)vite\.config\./i.test(name));
  const hasFirebase = names.some((name) => /firebase|firestore\.rules/i.test(name));
  const hasSrc = names.some((name) => /(^|\/)src\//i.test(name));
  const topFolders = [...new Set(names.map((name) => name.split('/')[0]).filter(Boolean))].slice(0, 30);
  const extensions = entries.reduce((acc, entry) => {
    if (entry.extension) acc[entry.extension] = (acc[entry.extension] || 0) + 1;
    return acc;
  }, {});
  return { hasPackage, hasVite, hasFirebase, hasSrc, topFolders, extensions };
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'POST only' });
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const file = body.file || {};
    const buffer = dataUrlToBuffer(file.routeDataUrl || '');
    if (!buffer.length) return json(res, 400, { ok: false, route: '/api/analyze-zip', error: 'No ZIP payload supplied.' });
    const entries = parseZipEntries(buffer);
    const files = entries.filter((entry) => !entry.directory);
    const folders = entries.filter((entry) => entry.directory);
    return json(res, 200, {
      ok: true,
      route: '/api/analyze-zip',
      analysedAt: new Date().toISOString(),
      file: { id: file.id || null, name: file.name || 'archive.zip', size: file.size || buffer.length, sizeLabel: formatBytes(file.size || buffer.length) },
      summary: `${files.length} file(s), ${folders.length} folder marker(s), ${formatBytes(buffer.length)} uploaded payload.`,
      entries: entries.slice(0, 160),
      projectSignals: buildProjectSignals(entries),
    });
  } catch (error) {
    return json(res, 500, { ok: false, route: '/api/analyze-zip', error: error.message || 'ZIP analysis failed safely.' });
  }
}
