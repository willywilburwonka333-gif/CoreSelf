const MAX_TEXT_CHARS = 18000;

function json(res, status, payload) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(payload));
}

function dataUrlToBuffer(dataUrl = '') {
  const match = String(dataUrl).match(/^data:([^;]+)?;base64,(.*)$/s);
  if (!match) return Buffer.alloc(0);
  return Buffer.from(match[2], 'base64');
}

function extensionFor(name = '') {
  const parts = String(name || '').toLowerCase().split('.');
  return parts.length > 1 ? parts.pop() : '';
}

function analyseText(text = '', name = '') {
  const clean = String(text || '').slice(0, MAX_TEXT_CHARS);
  const lines = clean ? clean.split(/\r?\n/) : [];
  const words = clean.trim() ? clean.trim().split(/\s+/).length : 0;
  const ext = extensionFor(name);
  const result = {
    parser: 'text-snippet',
    chars: clean.length,
    lines: lines.length,
    words,
    preview: clean.slice(0, 1800),
    signals: [],
  };

  if (ext === 'json') {
    try {
      const parsed = JSON.parse(clean);
      result.parser = 'json';
      result.jsonType = Array.isArray(parsed) ? 'array' : typeof parsed;
      result.topLevelKeys = parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? Object.keys(parsed).slice(0, 40) : [];
      result.signals.push('Valid JSON parsed.');
    } catch (error) {
      result.signals.push(`JSON parse warning: ${error.message}`);
    }
  }

  if (['js', 'jsx', 'ts', 'tsx', 'css', 'html'].includes(ext)) {
    const imports = [...clean.matchAll(/^\s*import\s+.*?from\s+['"]([^'"]+)['"]/gm)].map((match) => match[1]).slice(0, 40);
    const exports = [...clean.matchAll(/^\s*export\s+(?:default\s+)?(?:function|const|class|async function)?\s*([A-Za-z0-9_$]*)/gm)].map((match) => match[1]).filter(Boolean).slice(0, 40);
    result.parser = 'code';
    result.imports = imports;
    result.exports = exports;
    result.signals.push(`${imports.length} import(s), ${exports.length} named export/function signal(s).`);
  }

  if (ext === 'csv') {
    const firstLine = lines[0] || '';
    result.parser = 'csv';
    result.columns = firstLine.split(',').map((item) => item.trim()).filter(Boolean).slice(0, 60);
    result.signals.push(`${result.columns.length} column(s) detected from first row.`);
  }

  return result;
}

function readImageDimensions(buffer) {
  if (buffer.length >= 24 && buffer.toString('ascii', 1, 4) === 'PNG') {
    return { format: 'png', width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
  }
  if (buffer.length >= 4 && buffer[0] === 0xff && buffer[1] === 0xd8) {
    let offset = 2;
    while (offset < buffer.length) {
      if (buffer[offset] !== 0xff) break;
      const marker = buffer[offset + 1];
      const length = buffer.readUInt16BE(offset + 2);
      if ([0xc0, 0xc1, 0xc2, 0xc3].includes(marker)) {
        return { format: 'jpeg', width: buffer.readUInt16BE(offset + 7), height: buffer.readUInt16BE(offset + 5) };
      }
      offset += 2 + length;
    }
    return { format: 'jpeg' };
  }
  if (buffer.length >= 10 && buffer.toString('ascii', 0, 4) === 'GIF8') {
    return { format: 'gif', width: buffer.readUInt16LE(6), height: buffer.readUInt16LE(8) };
  }
  return null;
}

function analyseBinary(file = {}) {
  const buffer = dataUrlToBuffer(file.routeDataUrl || file.previewUrl || '');
  const ext = extensionFor(file.name);
  const base = {
    parser: 'binary-metadata',
    bytesReceived: buffer.length,
    extension: ext,
    routeNote: 'Server route received the file payload and extracted safe metadata. Full semantic parsing/transcription comes in later specialist routes.',
  };

  if (String(file.type || '').startsWith('image/') || file.kind === 'image') {
    const dimensions = readImageDimensions(buffer);
    return { ...base, parser: 'image-metadata', dimensions, routeNote: dimensions ? 'Image metadata route read dimensions from the uploaded payload.' : base.routeNote };
  }

  if (ext === 'pdf') {
    const header = buffer.slice(0, 8).toString('ascii');
    return { ...base, parser: 'pdf-metadata', isPdfHeader: header.startsWith('%PDF'), routeNote: 'PDF route confirms file payload and header. Text extraction/OCR is not enabled yet.' };
  }

  return base;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return json(res, 405, { ok: false, error: 'POST only' });
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const files = Array.isArray(body.files) ? body.files.slice(0, 8) : [];
    const analyses = files.map((file) => {
      const hasText = typeof file.textSnippet === 'string' && file.textSnippet.length > 0;
      const analysis = hasText ? analyseText(file.textSnippet, file.name) : analyseBinary(file);
      return {
        id: file.id || null,
        name: file.name || 'attached-file',
        kind: file.kind || 'file',
        type: file.type || 'unknown',
        size: file.size || 0,
        ok: true,
        analysis,
      };
    });
    return json(res, 200, { ok: true, route: '/api/analyze-file', analysedAt: new Date().toISOString(), analyses });
  } catch (error) {
    return json(res, 500, { ok: false, route: '/api/analyze-file', error: error.message || 'File analysis failed safely.' });
  }
}
