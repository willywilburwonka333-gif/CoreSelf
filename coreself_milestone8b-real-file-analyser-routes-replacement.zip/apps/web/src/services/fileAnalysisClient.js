function safeAnalysisFailure(error, route = 'file-analysis') {
  return {
    ok: false,
    route,
    error: error?.message || 'File analysis failed safely.',
    analysedAt: new Date().toISOString(),
  };
}

async function postJson(route, payload) {
  const response = await fetch(route, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || data.ok === false) throw new Error(data.error || `${route} failed with ${response.status}`);
  return data;
}

export async function analyseAttachments(attachments = []) {
  const files = Array.isArray(attachments) ? attachments : [];
  if (!files.length) return { ok: true, route: 'none', analyses: [], zipAnalyses: [] };

  const generalFiles = files.filter((file) => file.kind !== 'archive');
  const zipFiles = files.filter((file) => file.kind === 'archive' && file.routeDataUrl);
  const results = { ok: true, route: 'file-analysis-batch', analyses: [], zipAnalyses: [], errors: [] };

  if (generalFiles.length) {
    try {
      const analysed = await postJson('/api/analyze-file', { files: generalFiles });
      results.analyses = analysed.analyses || [];
    } catch (error) {
      results.errors.push(safeAnalysisFailure(error, '/api/analyze-file'));
    }
  }

  for (const file of zipFiles) {
    try {
      const analysedZip = await postJson('/api/analyze-zip', { file });
      results.zipAnalyses.push(analysedZip);
    } catch (error) {
      results.errors.push(safeAnalysisFailure(error, '/api/analyze-zip'));
    }
  }

  results.ok = results.errors.length === 0;
  return results;
}

export function summarizeFileAnalysisResults(results = {}) {
  const lines = [];
  if (Array.isArray(results.analyses)) {
    results.analyses.forEach((item, index) => {
      const analysis = item.analysis || {};
      const extras = [];
      if (analysis.parser) extras.push(analysis.parser);
      if (analysis.lines !== undefined) extras.push(`${analysis.lines} line(s)`);
      if (analysis.chars !== undefined) extras.push(`${analysis.chars} char(s)`);
      if (analysis.dimensions?.width) extras.push(`${analysis.dimensions.width}x${analysis.dimensions.height}`);
      lines.push(`${index + 1}. ${item.name} — ${item.kind}. ${extras.join(' • ') || 'metadata read'}.`);
    });
  }
  if (Array.isArray(results.zipAnalyses)) {
    results.zipAnalyses.forEach((item, index) => {
      lines.push(`ZIP ${index + 1}. ${item.file?.name || 'archive'} — ${item.summary || 'archive inspected'}. Top folders: ${(item.projectSignals?.topFolders || []).slice(0, 8).join(', ') || 'none'}.`);
    });
  }
  if (Array.isArray(results.errors) && results.errors.length) {
    results.errors.forEach((item) => lines.push(`Warning: ${item.route} — ${item.error}`));
  }
  return lines.join('\n') || 'No analyzer route results.';
}
