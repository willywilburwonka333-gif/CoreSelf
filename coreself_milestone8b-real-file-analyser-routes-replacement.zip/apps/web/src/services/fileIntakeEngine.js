const MAX_FILES = 8;
const MAX_TOTAL_BYTES = 25 * 1024 * 1024;
const MAX_SNIPPET_CHARS = 9000;
const MAX_IMAGE_PREVIEW_BYTES = 650 * 1024;
const MAX_ROUTE_PAYLOAD_BYTES = 8 * 1024 * 1024;

const TEXT_EXTENSIONS = ['txt', 'md', 'markdown', 'js', 'jsx', 'ts', 'tsx', 'json', 'css', 'html', 'csv', 'xml', 'yml', 'yaml', 'env', 'log'];
const ARCHIVE_EXTENSIONS = ['zip', 'rar', '7z', 'tar', 'gz'];
const DOC_EXTENSIONS = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pages', 'numbers', 'key'];
const ROUTE_PAYLOAD_EXTENSIONS = ['zip', 'pdf'];

function extensionFor(name = '') {
  const clean = String(name || '').toLowerCase();
  const parts = clean.split('.');
  return parts.length > 1 ? parts.pop() : '';
}

function classifyFile(file = {}) {
  const type = String(file.type || '').toLowerCase();
  const ext = extensionFor(file.name);
  if (type.startsWith('image/')) return 'image';
  if (type.startsWith('audio/')) return 'audio';
  if (type.startsWith('video/')) return 'video';
  if (ARCHIVE_EXTENSIONS.includes(ext)) return 'archive';
  if (DOC_EXTENSIONS.includes(ext)) return 'document';
  if (TEXT_EXTENSIONS.includes(ext) || type.startsWith('text/') || type.includes('json') || type.includes('javascript')) return 'text';
  return 'file';
}

function formatBytes(bytes = 0) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 / 1024).toFixed(2)} MB`;
}

function readAsText(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || '').slice(0, MAX_SNIPPET_CHARS));
    reader.onerror = () => resolve('');
    reader.readAsText(file);
  });
}

function readAsDataUrl(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => resolve('');
    reader.readAsDataURL(file);
  });
}

export function describeFileIntake(files = []) {
  const items = Array.from(files || []);
  const totalBytes = items.reduce((sum, file) => sum + Number(file.size || 0), 0);
  const kinds = [...new Set(items.map(classifyFile))];
  return {
    count: items.length,
    totalBytes,
    totalSize: formatBytes(totalBytes),
    kinds,
    canAttach: items.length <= MAX_FILES && totalBytes <= MAX_TOTAL_BYTES,
    limitMessage: items.length > MAX_FILES
      ? `Too many files. Attach up to ${MAX_FILES} files at once.`
      : totalBytes > MAX_TOTAL_BYTES
        ? `Too large for this intake step. Keep one send under ${formatBytes(MAX_TOTAL_BYTES)}.`
        : '',
  };
}

export async function prepareFileAttachments(fileList = []) {
  const files = Array.from(fileList || []).slice(0, MAX_FILES);
  const intake = describeFileIntake(files);
  if (!intake.canAttach) return { ok: false, reason: intake.limitMessage, attachments: [], intake };

  const attachments = await Promise.all(files.map(async (file) => {
    const kind = classifyFile(file);
    const base = {
      id: `file-${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name: file.name || 'attached-file',
      type: file.type || 'unknown',
      kind,
      size: file.size || 0,
      sizeLabel: formatBytes(file.size || 0),
      lastModified: file.lastModified ? new Date(file.lastModified).toISOString() : null,
      summary: `${kind.toUpperCase()} • ${file.name || 'file'} • ${formatBytes(file.size || 0)}`,
    };

    if (kind === 'text' && file.size <= 1024 * 1024) {
      const text = await readAsText(file);
      return {
        ...base,
        textSnippet: text,
        analysisReady: Boolean(text),
        intakeNote: text ? 'Text/code snippet attached for Dylan Core analysis.' : 'Text file attached, but preview failed safely.',
      };
    }

    if (kind === 'image') {
      const previewUrl = file.size <= MAX_IMAGE_PREVIEW_BYTES ? await readAsDataUrl(file) : '';
      const routeDataUrl = file.size <= MAX_ROUTE_PAYLOAD_BYTES ? (previewUrl || await readAsDataUrl(file)) : '';
      return {
        ...base,
        previewUrl,
        routeDataUrl,
        routeReady: Boolean(routeDataUrl),
        analysisReady: Boolean(previewUrl || routeDataUrl),
        intakeNote: routeDataUrl
          ? 'Image preview attached and ready for the real file analyzer route.'
          : 'Image attached. File is metadata only because it is too large for this safe route step.',
      };
    }

    const ext = extensionFor(file.name);
    const canSendToRoute = file.size <= MAX_ROUTE_PAYLOAD_BYTES && (kind === 'archive' || ROUTE_PAYLOAD_EXTENSIONS.includes(ext));
    const routeDataUrl = canSendToRoute ? await readAsDataUrl(file) : '';

    return {
      ...base,
      routeDataUrl,
      routeReady: Boolean(routeDataUrl),
      analysisReady: Boolean(routeDataUrl),
      intakeNote: kind === 'archive'
        ? (routeDataUrl ? 'ZIP/archive attached and ready for /api/analyze-zip.' : 'ZIP/archive attached as metadata only. Keep ZIPs under 8 MB for route inspection in this milestone.')
        : kind === 'audio'
          ? 'Audio/music attached. Metadata is ready; transcription/audio analysis needs the audio route next.'
          : kind === 'video'
            ? 'Video attached. Metadata is ready; video analysis needs the video route next.'
            : kind === 'document'
              ? (routeDataUrl ? 'Document/PDF attached and ready for /api/analyze-file metadata inspection.' : 'Document attached as metadata only. Full document parsing comes in a later route.')
              : 'File attached. Metadata is ready; binary analysis route comes next.',
    };
  }));

  return { ok: true, attachments, intake: describeFileIntake(attachments) };
}

export function summarizeAttachmentsForPrompt(attachments = []) {
  if (!attachments.length) return 'No files attached.';
  return attachments.map((file, index) => {
    const snippet = file.textSnippet ? `\nSnippet:\n${String(file.textSnippet).slice(0, 2000)}` : '';
    return `${index + 1}. ${file.name} — ${file.kind} / ${file.type || 'unknown'} / ${file.sizeLabel || formatBytes(file.size)}. ${file.intakeNote || ''}${snippet}`;
  }).join('\n\n');
}

export function buildFileIntakePlan({ attachments = [], input = '' } = {}) {
  const kinds = [...new Set(attachments.map((file) => file.kind))];
  const hasArchive = kinds.includes('archive');
  const hasImage = kinds.includes('image');
  const hasAudio = kinds.includes('audio');
  const hasVideo = kinds.includes('video');
  const hasText = kinds.includes('text');
  const hasDocument = kinds.includes('document');

  return {
    active: attachments.length > 0,
    count: attachments.length,
    kinds,
    summary: attachments.length ? `${attachments.length} attachment(s): ${kinds.join(', ')}` : 'No file intake active.',
    immediateCapabilities: [
      hasText ? 'Read attached text/code snippets immediately.' : null,
      hasImage ? 'Run real file analyzer route for image metadata and safe dimensions when payload is available.' : null,
      hasArchive ? 'Run /api/analyze-zip for small ZIP/archive file tree and project signals.' : null,
      hasAudio ? 'Recognise audio/music and prepare transcription/music workflow; audio route comes next.' : null,
      hasVideo ? 'Recognise video and prepare video workflow; video route comes next.' : null,
      hasDocument ? 'Run /api/analyze-file for document/PDF payload metadata; full text extraction comes later.' : null,
    ].filter(Boolean),
    nextRequiredRoutes: [
      hasArchive ? '/api/analyze-zip' : null,
      hasDocument ? '/api/analyze-file' : null,
      hasImage ? '/api/analyze-file' : null,
      hasAudio ? '/api/analyze-audio' : null,
      hasVideo ? '/api/analyze-video' : null,
    ].filter(Boolean),
    userIntent: String(input || '').trim(),
    rules: [
      'Use the attachment names/types/sizes as part of the answer.',
      'If a text/code snippet is included, analyse the snippet directly.',
      'Use analyzer route results when supplied; do not pretend to extract PDF text, audio transcripts, video content or full image semantics until those specialist routes exist.',
      'For ZIP/project uploads, prepare exact next steps for server-side inspection and changed-file workflow.',
    ],
  };
}
